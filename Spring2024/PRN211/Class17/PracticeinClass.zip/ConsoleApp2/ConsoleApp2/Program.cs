﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BaiTapManager b= new BaiTapManager();
            /* b.Question1();
             b.Question2();
             b.Question3();
             b.Question4();
             b.Question5();
             b.Question6();
            
            b.Question7();
            b.Question8();*/
            //b.Question9();
            b.Question6();

        }
    }
}
