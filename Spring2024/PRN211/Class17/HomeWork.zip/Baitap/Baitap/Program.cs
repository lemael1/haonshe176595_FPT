﻿namespace Baitap
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BaiTapManager b = new BaiTapManager();
            /*b.Question1();*/
            //b.Question2();
            //b.Question3();
            b.Question4();
        }
    }
}
