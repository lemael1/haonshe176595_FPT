/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Suppliers;

/**
 *
 * @author 1112v
 */
// String supplierID;
//    String suppliername;
//    Date birthdate;
//    Boolean gender;
//    String address;
public class DAO extends DBContext {

    public List<Suppliers> GetAllUser() {
        String sql = "select * from Suppliers";
        List<Suppliers> list = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Suppliers u = new Suppliers();
                u.setSupplierID(rs.getString(1));
                u.setSuppliername(rs.getString(2));
                u.setBirthdate(rs.getDate(3));
                u.setGender(rs.getBoolean(4));
                u.setAddress(rs.getString(5));
                list.add(u);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static void main(String[] args) {
        DAO d = new DAO();
        System.out.println(d.GetAllUser());
    }

    public void deletebyID(String id) {
        DAO d = new DAO();
        List<Suppliers> list = d.GetAllUser();
        String sql = "DELETE FROM [dbo].[Suppliers]\n"
                + "      WHERE id=?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, id);
            ResultSet rs = st.executeQuery();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

}
