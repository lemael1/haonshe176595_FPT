/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author 1112v
 */
public class Suppliers {
//    [SupplierID] [nvarchar](10) NOT NULL primary key,
//	[SupplierName] [nvarchar](30) NOT NULL,
//	[BirthDate] datetime not NULL,
//	[Gender] [bit] NULL,
//	[Address] [nvarchar](50) NULL
    String supplierID;
    String suppliername;
    Date birthdate;
    Boolean gender;
    String address;

    public Suppliers() {
    }

    public Suppliers(String supplierID, String suppliername, Date birthdate, Boolean gender, String address) {
        this.supplierID = supplierID;
        this.suppliername = suppliername;
        this.birthdate = birthdate;
        this.gender = gender;
        this.address = address;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public String getSuppliername() {
        return suppliername;
    }

    public void setSuppliername(String suppliername) {
        this.suppliername = suppliername;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    public Boolean getGender() {
        return gender;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
}
