/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author Hoang Hiep
 */
public class Thread {
    private int tid;
    private String tcontent;
    private ArrayList<Comment> comments;

    public Thread() {
    }

    public Thread(int tid, String tcontent, ArrayList<Comment> comments) {
        this.tid = tid;
        this.tcontent = tcontent;
        this.comments = comments;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    public String getTcontent() {
        return tcontent;
    }

    public void setTcontent(String tcontent) {
        this.tcontent = tcontent;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }
    
    
}
