/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Student;

/**
 *
 * @author 1112v
 */
public class DAO extends DBContext {
    public List<Student> GetAllStudent() {
        String sql = "select * from Student";
        List<Student> list = new ArrayList<>();
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Student s= new Student();
                s.setSid(rs.getInt(1));
                s.setName(rs.getString(2));
                s.setGender(rs.getBoolean(3));
                s.setDob(rs.getDate(4));
                list.add(s);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Student> GetStudentbychar(String name) {
        DAO d= new DAO();
        List<Student> list=d.GetAllStudent();
        List<Student> list_name= new ArrayList<>();
        for(int i=0;i<list.size();i++){
        if(list.get(i).getName().contains(name)){
        list_name.add(list.get(i));
        }
        }
       return list_name;
    }
}
